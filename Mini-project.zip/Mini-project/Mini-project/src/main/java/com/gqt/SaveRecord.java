package com.gqt;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SaveRecord extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Step 1: Get data from form
            int sid = Integer.parseInt(request.getParameter("sid"));
            String name = request.getParameter("fn");
            String gender = request.getParameter("gender");
            String city = request.getParameter("city");
            String course = request.getParameter("course");
            float amount = Float.parseFloat(request.getParameter("amount"));

            // Step 2: Create Student object
            Student s1 = new Student();
            s1.setSid(sid);
            s1.setName(name);
            s1.setGender(gender);
            s1.setCity(city);
            s1.setCourse(course);
            s1.setAmount(amount);

            // Step 3: Save to database using Hibernate
            SessionFactory sf = new Configuration().configure().buildSessionFactory();
            Session session = sf.openSession();
            session.beginTransaction();
            session.save(s1);
            session.getTransaction().commit();
            session.close();

            // Step 4: Redirect to save.jsp
            response.sendRedirect(request.getContextPath() + "/save.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
